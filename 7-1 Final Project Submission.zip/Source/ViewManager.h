///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "camera.h"
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>  // For glm::clamp

class ViewManager
{
public:
    // Constructor & Destructor
    ViewManager(ShaderManager* pShaderManager);
    ~ViewManager();

    // Callbacks for window and input events
    static void Mouse_Position_Callback(GLFWwindow* window, double xpos, double ypos);
    static void Scroll_Callback(GLFWwindow* window, double xoffset, double yoffset);
    static void FramebufferSize_Callback(GLFWwindow* window, int width, int height);

    // Create the GLFW window and register callbacks
    GLFWwindow* CreateDisplayWindow(const char* windowTitle);

    // Update view and projection matrices each frame
    void PrepareSceneView();

private:
    // Handle keyboard input for camera movement and projection toggle
    void ProcessKeyboardEvents();

    ShaderManager* m_pShaderManager = nullptr;
    GLFWwindow* m_pWindow = nullptr;
};
