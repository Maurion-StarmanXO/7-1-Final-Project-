///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////
#include "ViewManager.h"

// GLM Math Header inclusions for matrix and vector operations
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// Namespace for global variables
namespace
{
    const int WINDOW_WIDTH = 1000;
    const int WINDOW_HEIGHT = 800;
    const char* g_ViewName = "view";             // Shader uniform name for view matrix
    const char* g_ProjectionName = "projection"; // Shader uniform name for projection matrix

    Camera* g_pCamera = nullptr;                 // Main camera pointer for 3D scene control

    // Mouse and movement state
    float gMovementSpeed = 2.5f;                 // Adjustable camera movement speed
    float gLastX = WINDOW_WIDTH / 2.0f;          // Last X position of the mouse
    float gLastY = WINDOW_HEIGHT / 2.0f;         // Last Y position of the mouse
    bool gFirstMouse = true;                     // First mouse move check to avoid jump

    // Frame timing
    float gDeltaTime = 0.0f;                     // Time between current and previous frame
    float gLastFrame = 0.0f;

    bool bOrthographicProjection = false;        // Toggle between perspective and orthographic
}

// Constructor: Initializes the window and default camera settings
ViewManager::ViewManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_pWindow = nullptr;
    g_pCamera = new Camera();

    // Default camera settings: elevated view looking downward
    g_pCamera->Position = glm::vec3(0.0f, 7.0f, 25.0f);
    g_pCamera->Front = glm::vec3(0.0f, -0.2f, -1.0f);
    g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
    g_pCamera->Zoom = 60.0f; // Field of view in degrees
}

// Destructor: Clean up dynamically allocated camera
ViewManager::~ViewManager()
{
    m_pShaderManager = nullptr;
    m_pWindow = nullptr;
    if (g_pCamera)
    {
        delete g_pCamera;
        g_pCamera = nullptr;
    }
}

// Framebuffer resize callback: adjust viewport on window resize
void ViewManager::FramebufferSize_Callback(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}

// Initializes GLFW display window and sets input callbacks
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
    GLFWwindow* window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, windowTitle, nullptr, nullptr);
    if (!window)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return nullptr;
    }
    glfwMakeContextCurrent(window);

    // Register callbacks
    glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);
    glfwSetScrollCallback(window, &ViewManager::Scroll_Callback);
    glfwSetFramebufferSizeCallback(window, &ViewManager::FramebufferSize_Callback);

    // Enable depth testing and alpha blending
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    m_pWindow = window;
    return window;
}

// Mouse movement callback: rotates camera based on mouse motion
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
    if (gFirstMouse)
    {
        gLastX = static_cast<float>(xMousePos);
        gLastY = static_cast<float>(yMousePos);
        gFirstMouse = false;
    }

    float xOffset = static_cast<float>(xMousePos - gLastX);
    float yOffset = static_cast<float>(gLastY - yMousePos); // Reversed for natural feel

    gLastX = static_cast<float>(xMousePos);
    gLastY = static_cast<float>(yMousePos);

    float sensitivity = 0.1f;
    xOffset *= sensitivity;
    yOffset *= sensitivity;

    g_pCamera->ProcessMouseMovement(xOffset, yOffset);
}

// Processes keyboard input for 3D camera navigation
void ViewManager::ProcessKeyboardEvents()
{
    if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(m_pWindow, true);

    if (!g_pCamera) return;

    float adjustedSpeed = gDeltaTime * gMovementSpeed;

    if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(FORWARD, adjustedSpeed);
    if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(BACKWARD, adjustedSpeed);
    if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(LEFT, adjustedSpeed);
    if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(RIGHT, adjustedSpeed);
    if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(UP, adjustedSpeed);
    if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(DOWN, adjustedSpeed);

    // Toggle projection mode
    if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS)
        bOrthographicProjection = !bOrthographicProjection;
}

// Scroll callback: adjust camera FOV and movement speed dynamically
void ViewManager::Scroll_Callback(GLFWwindow* window, double xoffset, double yoffset)
{
    // Zoom in/out
    g_pCamera->ProcessMouseScroll(static_cast<float>(yoffset));

    // Adjust movement speed
    gMovementSpeed += static_cast<float>(yoffset) * 0.1f;
    gMovementSpeed = glm::clamp(gMovementSpeed, 0.1f, 10.0f);

    std::cout << "Movement speed: " << gMovementSpeed << std::endl;
}

// Updates the scene's view and projection matrices every frame
void ViewManager::PrepareSceneView()
{
    // Update timing
    float currentFrame = static_cast<float>(glfwGetTime());
    gDeltaTime = currentFrame - gLastFrame;
    gLastFrame = currentFrame;

    ProcessKeyboardEvents();

    glm::mat4 view = g_pCamera->GetViewMatrix();
    int width, height;
    glfwGetFramebufferSize(m_pWindow, &width, &height);
    float aspect = static_cast<float>(width) / static_cast<float>(height);

    glm::mat4 projection;
    if (bOrthographicProjection)
    {
        float orthoScale = 10.0f;
        projection = glm::ortho(-orthoScale * aspect,
            orthoScale * aspect,
            -orthoScale,
            orthoScale,
            0.1f, 100.0f);
    }
    else
    {
        projection = glm::perspective(glm::radians(g_pCamera->Zoom),
            aspect,
            0.1f, 100.0f);
    }

    if (m_pShaderManager)
    {
        m_pShaderManager->setMat4Value(g_ViewName, view);
        m_pShaderManager->setMat4Value(g_ProjectionName, projection);
        m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
    }
}
