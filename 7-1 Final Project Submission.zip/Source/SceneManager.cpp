﻿///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declare the global variables
namespace
{
	// model, color, texture uniforms…
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";

	// lighting uniforms
	const char* g_UseLightingName = "u_UseLighting";
	const char* g_NumLightsName = "u_NumLights";
}


/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// initialize the texture collection
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	// clear the allocated memory
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
	// destroy the created OpenGL textures
	DestroyGLTextures();
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

void SceneManager::LoadSceneTextures()
{
	bool bReturn = false;


	bReturn = CreateGLTexture("../../Utilities/textures/abstract.jpg", "bottle");

	bReturn = CreateGLTexture("../../Utilities/textures/stainedglass.jpg", "floor");

	bReturn = CreateGLTexture("../../Utilities/textures/knife_handle.jpg", "knifehandle");

	bReturn = CreateGLTexture("../../Utilities/textures/stainless.jpg", "metal");

	bReturn = CreateGLTexture("../../Utilities/textures/orange.jpg", "orange");

	bReturn = CreateGLTexture("../../Utilities/textures/mug.jpg", "mug");


	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots - there
	// are a total of 16 available slots for scene textures
	BindGLTextures();
}
void SceneManager::SetShaderMaterial(std::string materialTag)
{
	if (m_objectMaterials.empty()) return;

	for (const auto& material : m_objectMaterials)
	{
		if (material.tag == materialTag)
		{
			if (m_pShaderManager)
			{
				m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
				m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
				m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
				m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
				m_pShaderManager->setFloatValue("material.shininess", material.shininess);
			}
			break;
		}
	}
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method is used for configuring the various material
 *  settings for all of the objects within the 3D scene.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// ── Floor Material ────────────────────────────────
	OBJECT_MATERIAL floorMat;
	floorMat.tag = "floor";
	floorMat.ambientStrength = 0.2f;
	floorMat.ambientColor = glm::vec3(0.8f, 1.7f, 0.6f);
	floorMat.diffuseColor = glm::vec3(0.6f, 0.5f, 0.4f);
	floorMat.specularColor = glm::vec3(1.3f, 6.2f, 1.1f);
	floorMat.shininess = 28.0f;// slightly glossier floor
	m_objectMaterials.push_back(floorMat);

	// ── Bottle Material ───────────────────────────────
	OBJECT_MATERIAL bottleMat;
	bottleMat.tag = "bottle";
	bottleMat.ambientStrength = 0.9f;
	bottleMat.ambientColor = glm::vec3(0.8f, 0.5f, 0.3f);
	bottleMat.diffuseColor = glm::vec3(0.8f, 0.5f, 0.3f);
	bottleMat.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	bottleMat.shininess = 64.0f;
	m_objectMaterials.push_back(bottleMat);

	// ── (Optional) Neck Material ──────────────────────
	OBJECT_MATERIAL neckMat = bottleMat;
	neckMat.tag = "neck";
	neckMat.diffuseColor = glm::vec3(0.9f, 0.6f, 0.4f);
	m_objectMaterials.push_back(neckMat);

	// ── (Optional) Lip Ring Material ──────────────────
	OBJECT_MATERIAL lipMat = bottleMat;
	lipMat.tag = "lip";
	lipMat.shininess = 128.0f;  // extra glossy
	m_objectMaterials.push_back(lipMat);

	// ── Orange Material ─────────────────────────────
	OBJECT_MATERIAL orangeMat;
	orangeMat.tag = "orange";
	orangeMat.ambientStrength = 0.3f;
	orangeMat.ambientColor = glm::vec3(0.9f, 0.4f, 0.1f);
	orangeMat.diffuseColor = glm::vec3(0.9f, 0.4f, 0.1f);
	orangeMat.specularColor = glm::vec3(0.3f, 0.2f, 0.2f);
	orangeMat.shininess = 16.0f;
	m_objectMaterials.push_back(orangeMat);

	// ── Ceramic Mug Material ────────────────────────
	OBJECT_MATERIAL ceramicMat;
	ceramicMat.tag = "mug";
	ceramicMat.ambientStrength = 0.3f;
	ceramicMat.ambientColor = glm::vec3(0.8f, 0.8f, 0.9f);
	ceramicMat.diffuseColor = glm::vec3(0.8f, 0.8f, 0.9f);
	ceramicMat.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	ceramicMat.shininess = 96.0f;
	m_objectMaterials.push_back(ceramicMat);

}


/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene.  There are up to 4 light sources.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// Enable lighting
	m_pShaderManager->setBoolValue("bUseLighting", true);

	// ── LIGHT 0 ── Key Light (left front)
	m_pShaderManager->setVec3Value("lightSources[0].position", glm::vec3(-3.0f, 4.0f, 6.0f));
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", glm::vec3(0.2f, 0.2f, 0.2f));
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", glm::vec3(1.0f, 1.0f, 1.0f));
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", glm::vec3(0.5f, 0.5f, 0.5f));
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 32.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.5f);

	// ── LIGHT 1 ── Strong Red Fill Light (right front)
	m_pShaderManager->setVec3Value("lightSources[1].position", glm::vec3(3.0f, 4.0f, 6.0f));
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", glm::vec3(0.4f, 0.0f, 0.0f));  // strong red ambient
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", glm::vec3(1.0f, 0.0f, 0.0f));  // pure red diffuse
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", glm::vec3(0.6f, 0.0f, 0.0f)); // red specular highlights
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 24.0f);                      // slightly wider spread
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.7f);                   // increase highlight

	// ── LIGHT 2 ── Soft Overhead Fill Light (heavily reduced)
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", glm::vec3(0.01f, 0.005f, 0.005f));
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", glm::vec3(0.02f, 0.01f, 0.01f));
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", glm::vec3(0.0f, 0.0f, 0.0f));
	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 8.0f);
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.0f);

	// ── LIGHT 3 ── Backlight (proper soft bounce)
	m_pShaderManager->setVec3Value("lightSources[3].position", glm::vec3(0.0f, 2.0f, -6.0f));
	m_pShaderManager->setVec3Value("lightSources[3].ambientColor", glm::vec3(0.05f, 0.02f, 0.02f)); // slight warm tone
	m_pShaderManager->setVec3Value("lightSources[3].diffuseColor", glm::vec3(0.1f, 0.05f, 0.05f));  // very gentle diffuse
	m_pShaderManager->setVec3Value("lightSources[3].specularColor", glm::vec3(0.05f, 0.02f, 0.02f)); // soft specular
	m_pShaderManager->setFloatValue("lightSources[3].focalStrength", 16.0f); // wider spread, softer falloff
	m_pShaderManager->setFloatValue("lightSources[3].specularIntensity", 0.05f); // barely shiny

}


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	LoadSceneTextures();
	DefineObjectMaterials();
	SetupSceneLights();

	// Load all shape meshes required for the full scene
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadPrismMesh();     // Optional: if using for knife/mug
	m_basicMeshes->LoadPyramid4Mesh();  // Optional: same
}

 /***********************************************************
  *  RenderScene()
  *
  *  This method is used for rendering the 3D scene by
  *  transforming and drawing the basic 3D shapes
  ***********************************************************/
void SceneManager::RenderScene()
{
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/***** Floor *****/
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderMaterial("floor");
	SetShaderTexture("floor");
	m_basicMeshes->DrawPlaneMesh();

	/***** Bottle Body (Cylinder) *****/
	scaleXYZ = glm::vec3(0.8f, 4.0f, 0.8f);
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderMaterial("bottle");
	SetShaderTexture("bottle");
	m_basicMeshes->DrawCylinderMesh();

	/***** Bottle Neck (Tapered Cylinder) *****/
	scaleXYZ = glm::vec3(0.8f, 2.5f, 0.8f);
	positionXYZ = glm::vec3(0.0f, 4.0f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderMaterial("neck");
	SetShaderTexture("bottle");
	m_basicMeshes->DrawTaperedCylinderMesh();

	/***** Bottle Top Extension (Tapered Cylinder) *****/
	scaleXYZ = glm::vec3(0.4f, 1.25f, 0.4f);
	positionXYZ = glm::vec3(0.0f, 6.5f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderMaterial("neck");
	SetShaderTexture("bottle");
	m_basicMeshes->DrawTaperedCylinderMesh();

	/***** Bottle Lip Ring (Torus) *****/
	scaleXYZ = glm::vec3(0.2f, 0.15f, 0.2f);
	positionXYZ = glm::vec3(0.0f, 7.775f, 0.0f);
	SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderMaterial("lip");
	SetShaderTexture("bottle");
	m_basicMeshes->DrawTorusMesh();

	/***** Orange (Sphere) *****/
	scaleXYZ = glm::vec3(1.2f, 1.2f, 1.2f);
	positionXYZ = glm::vec3(-4.0f, 1.2f, 2.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("orange");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("orange");
	m_basicMeshes->DrawSphereMesh();

	/***** Mug Body (Cylinder) *****/
	scaleXYZ = glm::vec3(1.0f, 2.2f, 1.0f);
	positionXYZ = glm::vec3(3.0f, 0.0f, -2.5f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("mug");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("mug");
	m_basicMeshes->DrawCylinderMesh(false, true, true);

	/***** Mug Handle (Torus) - Corrected *****/
	scaleXYZ = glm::vec3(0.35f, 0.60f, 0.35f);  // Thicker and slightly larger
	positionXYZ = glm::vec3(4.2f, 1.0f, -2.5f); // Same position
	SetTransformations(scaleXYZ, 0.0f, 175.0f, 0.0f, positionXYZ);
	SetShaderMaterial("ceramic");
	SetShaderTexture("mug");
	m_basicMeshes->DrawTorusMesh();


	/***** Knife Handle (Box) *****/
	scaleXYZ = glm::vec3(0.2f, 0.2f, 1.2f);
	positionXYZ = glm::vec3(1.0f, .10f, 2.0f); // right and forward
	SetTransformations(scaleXYZ, 0.0f, 45.0f, 0.0f, positionXYZ);
	SetShaderMaterial("wood");
	SetShaderTexture("knifehandle");
	m_basicMeshes->DrawBoxMesh();

	/***** Knife Blade (Prism) *****/
	scaleXYZ = glm::vec3(0.1f, 0.1f, 1.5f);
	positionXYZ = glm::vec3(2.0f, .12f, 3.0f);  // Extend blade forward
	SetTransformations(scaleXYZ, 0.0f, 45.0f, 0.0f, positionXYZ);
	SetShaderMaterial("metal");
	SetShaderTexture("bottle");
	m_basicMeshes->DrawPrismMesh();
}


